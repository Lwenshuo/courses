function run_all_demos
%RUN_ALL_DEMOS Run the complete lecture demo sequence.
root = fileparts(mfilename('fullpath'));
addpath(root, fullfile(root,'demos'), fullfile(root,'helpers'));

names = {
    'demo01_frames_and_notation'
    'demo02_rotation_2d'
    'demo03_rotation_3d_xyz'
    'demo04_rotation_properties_columns'
    'demo05_rotation_composition_inverse'
    'demo06_translation_rigid_transform'
    'demo07_homogeneous_points_vectors'
    'demo08_transform_composition_inverse'
    'demo09_coordinate_chain_camera_base'
    'demo10_joint_chain_and_q'
    'demo11_planar_1R_fk'
    'demo12_planar_2R_geometric'
    'demo13_planar_2R_homogeneous'
    'demo14_planar_2R_numeric'
    'demo15_serial_chain_and_dh'
    'demo16_ur5e_forward_kinematics'
    'demo17_ur5e_wrist_camera_chain'
    'demo18_debugging_checks'
    };

fprintf('Running %d demos...\n', numel(names));
for k = 1:numel(names)
    fprintf('\n[%02d/%02d] %s\n', k, numel(names), names{k});
    try
        feval(names{k});
    catch ME
        warning('Demo %s failed: %s', names{k}, ME.message);
    end
end
fprintf('\nAll demos attempted.\n');
end
