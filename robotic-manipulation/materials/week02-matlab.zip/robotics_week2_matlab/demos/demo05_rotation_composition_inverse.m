function demo05_rotation_composition_inverse
% Slides 18-21: composition, noncommutativity, inverse, self-check.
root=fileparts(fileparts(mfilename('fullpath'))); addpath(fullfile(root,'helpers'));
clc; Rx=rotx3(deg2rad(30)); Rz=rotz3(deg2rad(60));
R1=Rz*Rx; R2=Rx*Rz;
fprintf('||Rz*Rx - Rx*Rz||_F = %.6f (nonzero -> order matters)\n',norm(R1-R2,'fro'));
fprintf('Inverse check ||R''R-I|| = %.3e\n',norm(R1.'*R1-eye(3),'fro'));
Rtest=[0 -1 0;1 0 0;0 0 1];
fprintf('\nSlide self-check matrix R=\n'); disp(Rtest);
fprintf('R*[1 0 0]^T = '); disp(Rtest*[1;0;0]);
fprintf('R^{-1}=R^T=\n'); disp(Rtest.');
figure('Name','Rotation order comparison'); t=tiledlayout(1,2);
for k=1:2
    ax=nexttile(t); hold(ax,'on'); grid(ax,'on'); axis(ax,'equal'); view(ax,3);
    plotFrame3D(ax,eye(4),'A',0.6); if k==1, R=R1; ttl='R_z R_x'; else, R=R2; ttl='R_x R_z'; end
    plotFrame3D(ax,homog(R,[0;0;0]),'B',0.9); title(ax,ttl); xlim(ax,[-1 1]); ylim(ax,[-1 1]); zlim(ax,[-1 1]);
end
end
