function demo09_coordinate_chain_camera_base
% Slides 29-32: camera/world/base chain and numeric rigid transform example.
root=fileparts(fileparts(mfilename('fullpath'))); addpath(fullfile(root,'helpers'));
clc;
% World->base, camera->world, target->camera
T_0W=homog(rotz3(deg2rad(10)),[0.30;-0.10;0.00]);
T_WC=homog(roty3(deg2rad(-15)),[0.50;0.20;0.80]);
T_CP=homog(rotz3(deg2rad(25)),[0.20;-0.05;0.60]);
T_0P=T_0W*T_WC*T_CP;
fprintf('T_0P = T_0W*T_WC*T_CP =\n'); disp(T_0P);

% Slide 31 planar numeric example
R=rot2(pi/2); pB=[1;0]; pBoriginA=[2;1]; pA=R*pB+pBoriginA;
fprintf('Slide 31 2D example result p_P^A = [%g %g]^T (expected [2 2]^T)\n',pA(1),pA(2));

% Verification ideas
fprintf('Checks: last row, R''R≈I, det(R)≈1, units, known landmark.\n');
figure('Name','Camera-world-base chain'); ax=axes; hold(ax,'on'); grid(ax,'on'); axis(ax,'equal'); view(ax,3);
plotFrame3D(ax,eye(4),'0 base',0.15); plotFrame3D(ax,T_0W,'W',0.15); plotFrame3D(ax,T_0W*T_WC,'C',0.15); plotFrame3D(ax,T_0P,'P',0.15);
xlim(ax,[-.2 1.2]); ylim(ax,[-.5 1]); zlim(ax,[-.2 1.8]);
end
