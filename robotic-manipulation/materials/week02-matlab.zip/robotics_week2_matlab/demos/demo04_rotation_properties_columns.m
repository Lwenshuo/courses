function demo04_rotation_properties_columns
% Slides 16-17: SO(3) checks and column interpretation.
root=fileparts(fileparts(mfilename('fullpath'))); addpath(fullfile(root,'helpers'));
clc; R=rotz3(deg2rad(35))*roty3(deg2rad(-20))*rotx3(deg2rad(10));
s=checkRotation(R);
fprintf('R^T R =\n'); disp(R.'*R); fprintf('det(R)=%.12f\n',det(R)); fprintf('orthogonality error=%.3e\n',s.orthogonalityError);
fprintf('Columns = target frame axes expressed in reference frame:\n');
fprintf('x_B^A = '); disp(R(:,1).'); fprintf('y_B^A = '); disp(R(:,2).'); fprintf('z_B^A = '); disp(R(:,3).');
figure('Name','Rotation columns'); ax=axes; hold(ax,'on'); axis(ax,'equal'); grid(ax,'on'); view(ax,3);
plotFrame3D(ax,eye(4),'A',0.7); plotFrame3D(ax,homog(R,[0;0;0]),'B',1.0); xlim(ax,[-1.2 1.2]); ylim(ax,[-1.2 1.2]); zlim(ax,[-1.2 1.2]);
end
