function demo12_planar_2R_geometric
% Slides 40-41: planar 2R geometry and formulas.
root=fileparts(fileparts(mfilename('fullpath'))); addpath(fullfile(root,'helpers'));
clc; l1=1; l2=0.6; q1=deg2rad(35); q2=deg2rad(50);
x=l1*cos(q1)+l2*cos(q1+q2); y=l1*sin(q1)+l2*sin(q1+q2); phi=q1+q2;
fprintf('2R geometric FK: x=%.4f y=%.4f phi=%.2f deg\n',x,y,rad2deg(phi));
figure('Name','2R geometric FK'); ax=axes; plotPlanar2R(ax,l1,l2,q1,q2); title(ax,'Planar 2R geometric FK');
text(ax,x,y,sprintf('  P(%.2f, %.2f)',x,y));
end
