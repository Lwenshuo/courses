function demo03_rotation_3d_xyz
% Slides 13-15: elementary 3D rotations.
root=fileparts(fileparts(mfilename('fullpath'))); addpath(fullfile(root,'helpers'));
clc; a=deg2rad(30); b=deg2rad(40); g=deg2rad(50);
Rx=rotx3(a); Ry=roty3(b); Rz=rotz3(g);
fprintf('Rx(30 deg)=\n'); disp(Rx); fprintf('Ry(40 deg)=\n'); disp(Ry); fprintf('Rz(50 deg)=\n'); disp(Rz);
figure('Name','Rx Ry Rz'); t=tiledlayout(1,3);
Rs={Rx,Ry,Rz}; names={'R_x','R_y','R_z'};
for k=1:3
    ax=nexttile(t); hold(ax,'on'); grid(ax,'on'); axis(ax,'equal'); view(ax,3);
    plotFrame3D(ax,eye(4),'base',0.6); plotFrame3D(ax,homog(Rs{k},[0;0;0]),names{k},0.9);
    xlim(ax,[-1 1]); ylim(ax,[-1 1]); zlim(ax,[-1 1]); title(ax,names{k});
end
end
