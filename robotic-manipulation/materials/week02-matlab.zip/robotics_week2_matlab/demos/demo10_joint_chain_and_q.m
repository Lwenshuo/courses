function demo10_joint_chain_and_q
% Slides 33-38: joint chain, joints/links, q, local frames, FK definition.
root=fileparts(fileparts(mfilename('fullpath'))); addpath(fullfile(root,'helpers'));
clc;
q=deg2rad([20 -35 45]); l=[0.7 0.6 0.4];
T=eye(4); Ts=cell(1,4); Ts{1}=T;
for i=1:3
    Ri=rotz3(q(i));
    Ti=homog(Ri,Ri*[l(i);0;0]);
    T=T*Ti; Ts{i+1}=T;
end
fprintf('q = '); disp(q); fprintf('End transform from simple 3R chain:\n'); disp(T);
figure('Name','Joint chain and q'); ax=axes; hold(ax,'on'); grid(ax,'on'); axis(ax,'equal'); view(ax,3);
for i=1:4, plotFrame3D(ax,Ts{i},sprintf('{%d}',i-1),0.12); end
pts=cell2mat(cellfun(@(X)X(1:3,4),Ts,'UniformOutput',false)); plot3(ax,pts(1,:),pts(2,:),pts(3,:),'-o','LineWidth',3);
title(ax,'Each joint changes the adjacent transform; FK multiplies the chain');
end
