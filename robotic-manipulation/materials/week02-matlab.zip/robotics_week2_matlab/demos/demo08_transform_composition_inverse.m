function demo08_transform_composition_inverse
% Slides 27-28: homogeneous transform composition and inverse.
root=fileparts(fileparts(mfilename('fullpath'))); addpath(fullfile(root,'helpers'));
clc;
T_AB=homog(rotz3(deg2rad(30)),[1;0;0.2]);
T_BC=homog(roty3(deg2rad(-20)),[0.4;0.2;0]);
T_AC=T_AB*T_BC;
T_CA=invHomog(T_AC);
fprintf('T_AC=T_AB*T_BC=\n'); disp(T_AC);
fprintf('Inverse analytic check ||T_CA*T_AC-I||=%.3e\n',norm(T_CA*T_AC-eye(4),'fro'));
fprintf('Translation inverse is -R^T p, not just -p.\n');
figure('Name','Transform chain'); ax=axes; hold(ax,'on'); grid(ax,'on'); axis(ax,'equal'); view(ax,3);
plotFrame3D(ax,eye(4),'A',0.25); plotFrame3D(ax,T_AB,'B',0.25); plotFrame3D(ax,T_AC,'C',0.25); xlim(ax,[-.5 2]); ylim(ax,[-.5 1.5]); zlim(ax,[-.5 1]);
end
