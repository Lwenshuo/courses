function demo18_debugging_checks
% Slide 46: forward-kinematics debugging checklist.
root=fileparts(fileparts(mfilename('fullpath'))); addpath(fullfile(root,'helpers'));
clc;
fprintf('=== FK debugging checklist ===\n');
fprintf('1) Check angle/length units and joint zero definitions.\n');
fprintf('2) Check local-transform directions and multiplication order.\n');
fprintf('3) Test zero pose, one joint at a time, and symmetric/simple poses.\n');
fprintf('4) Compare analytical results with simulation or measured landmarks.\n\n');

% Deliberately wrong: degrees used as radians.
l1=1; l2=0.5; q1_wrong=30; q2_wrong=60;
xWrong=l1*cos(q1_wrong)+l2*cos(q1_wrong+q2_wrong);
yWrong=l1*sin(q1_wrong)+l2*sin(q1_wrong+q2_wrong);
q1=deg2rad(30); q2=deg2rad(60);
xRight=l1*cos(q1)+l2*cos(q1+q2); yRight=l1*sin(q1)+l2*sin(q1+q2);
fprintf('Wrong degree/radian result: x=%.3f, y=%.3f\n',xWrong,yWrong);
fprintf('Correct result:            x=%.3f, y=%.3f\n',xRight,yRight);

% Rotation validity check.
Rbad=[1 0 0;0 1 0;0 0 0.95]; s=checkRotation(Rbad);
fprintf('\nBad R: det=%.3f, orthogonality error=%.3e -> valid rotation? %d\n',s.determinant,s.orthogonalityError,s.isRotation);
end
