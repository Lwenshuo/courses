function demo14_planar_2R_numeric
% Slide 43 numeric example.
root=fileparts(fileparts(mfilename('fullpath'))); addpath(fullfile(root,'helpers'));
clc; l1=1; l2=0.5; q1=deg2rad(30); q2=deg2rad(60);
x=l1*cos(q1)+l2*cos(q1+q2); y=l1*sin(q1)+l2*sin(q1+q2); phi=q1+q2;
fprintf('Expected from slides: x=0.866 m, y=1.000 m, phi=90 deg\n');
fprintf('Computed: x=%.6f m, y=%.6f m, phi=%.2f deg\n',x,y,rad2deg(phi));
assert(abs(x-0.8660254)<1e-6 && abs(y-1)<1e-12);
figure('Name','2R numeric example'); ax=axes; plotPlanar2R(ax,l1,l2,q1,q2); title(ax,'l_1=1, l_2=0.5, q_1=30°, q_2=60°');
end
