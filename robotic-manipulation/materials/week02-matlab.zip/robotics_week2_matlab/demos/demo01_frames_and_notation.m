function demo01_frames_and_notation
% Slides 5-9: coordinate frames, notation, points and vectors.
root=fileparts(fileparts(mfilename('fullpath'))); addpath(fullfile(root,'helpers'));
clc;
T_A=eye(3); T_B=tform2d(deg2rad(30),[2;1]);
pB=[1;0.5;1]; pA=T_B*pB;

fprintf('p_P^B = [%g, %g]^T\n',pB(1),pB(2));
fprintf('p_P^A = [%g, %g]^T\n',pA(1),pA(2));
fprintf('Same physical point, different coordinate values.\n');

figure('Name','Frames and notation'); ax=axes; hold(ax,'on'); grid(ax,'on'); axis(ax,'equal');
plotFrame2D(ax,T_A,'A',0.7); plotFrame2D(ax,T_B,'B',0.7);
plot(ax,pA(1),pA(2),'ko','MarkerFaceColor','k'); text(ax,pA(1),pA(2),'  P');
xlim(ax,[-1 4]); ylim(ax,[-1 3]); title(ax,'Same point P expressed in frames A and B');
end
