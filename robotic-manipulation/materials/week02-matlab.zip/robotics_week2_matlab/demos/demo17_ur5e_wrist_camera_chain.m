function demo17_ur5e_wrist_camera_chain
% Built-in UR5e + wrist camera transform chain.
% Slides 29-30: T_0P = T_0E * T_EC * T_CP.
root=fileparts(fileparts(mfilename('fullpath'))); addpath(fullfile(root,'helpers'));
clc;
if exist('loadrobot','file')~=2
    warning('Robotics System Toolbox/loadrobot not found. Skipping UR5e camera demo.'); return;
end
try
    robot=loadrobot("universalUR5e",DataFormat="row");
catch ME
    warning('Could not load universalUR5e: %s',ME.message); return;
end
q=homeConfiguration(robot); q(:)=0;
vals=[0 -pi/4 pi/2 -pi/4 -pi/2 pi/6]; q(1:min(6,numel(q)))=vals(1:min(6,numel(q)));
ee=robot.BodyNames{end};
T0E=getTransform(robot,q,ee);
% Fixed hand-eye calibration: camera 8 cm forward, 5 cm above tool, rotated 90 deg about z.
TEC=homog(rotz3(pi/2),[0.08;0;0.05]);
% Target pose in camera coordinates (example from vision/PnP).
TCP=homog(rotx3(deg2rad(10)),[0.35;-0.05;0.55]);
T0P=T0E*TEC*TCP;
fprintf('T_0P = T_0E * T_EC * T_CP =\n'); disp(T0P);

figure('Name','UR5e wrist-camera chain');
ax=axes; show(robot,q,'Frames','off','PreservePlot',false,'Parent',ax); hold(ax,'on'); axis(ax,'equal'); view(ax,135,20); grid(ax,'on');
plotFrame3D(ax,T0E,'E',0.08); plotFrame3D(ax,T0E*TEC,'C',0.08); plotFrame3D(ax,T0P,'P',0.08);
title(ax,'UR5e wrist camera:  ^0T_P = ^0T_E ^ET_C ^CT_P');
end
