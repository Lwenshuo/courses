function demo15_serial_chain_and_dh
% Slides 44-45: generic serial chain and standard DH preview.
root=fileparts(fileparts(mfilename('fullpath'))); addpath(fullfile(root,'helpers'));
clc;
q=deg2rad([20 -30 40]); d=[0.2 0 0]; a=[0.5 0.45 0.3]; alpha=deg2rad([0 0 0]);
T=eye(4);
for i=1:3
    Ti = dhStandard(q(i),d(i),a(i),alpha(i));
    fprintf('A_%d =\n',i); disp(Ti);
    T=T*Ti;
end
fprintf('Total T_0^3 =\n'); disp(T);
fprintf('Standard DH parameters: theta, d, a, alpha.\n');
end

function A=dhStandard(theta,d,a,alpha)
ct=cos(theta); st=sin(theta); ca=cos(alpha); sa=sin(alpha);
A=[ct -st*ca st*sa a*ct;
   st ct*ca -ct*sa a*st;
   0 sa ca d;
   0 0 0 1];
end
