function demo07_homogeneous_points_vectors
% Slides 24-26: homogeneous transform, point vs direction.
root=fileparts(fileparts(mfilename('fullpath'))); addpath(fullfile(root,'helpers'));
clc; R=rotz3(deg2rad(45)); p=[1;2;0.5]; T=homog(R,p);
pointB=[0.4;0.2;0.1;1]; dirB=[1;0;0;0];
pointA=T*pointB; dirA=T*dirB;
fprintf('T_AB=\n'); disp(T);
fprintf('Point transforms with rotation + translation:\n'); disp(pointA.');
fprintf('Direction transforms with rotation only:\n'); disp(dirA.');
fprintf('Last coordinate: point=%g, direction=%g\n',pointA(4),dirA(4));
end
