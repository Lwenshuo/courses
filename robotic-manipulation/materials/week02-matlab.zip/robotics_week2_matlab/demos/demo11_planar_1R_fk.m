function demo11_planar_1R_fk
% Slide 39: single revolute-joint FK.
clc; l=1.0; theta=deg2rad(50); x=l*cos(theta); y=l*sin(theta); phi=theta;
fprintf('x=%.4f, y=%.4f, phi=%.2f deg\n',x,y,rad2deg(phi));
figure('Name','1R planar FK'); ax=axes; hold(ax,'on'); grid(ax,'on'); axis(ax,'equal');
plot(ax,[0 x],[0 y],'-o','LineWidth',5); plot(ax,x,y,'ko','MarkerFaceColor','k');
tt=linspace(0,2*pi,240); plot(ax,l*cos(tt),l*sin(tt),'--','LineWidth',1); xlabel(ax,'x'); ylabel(ax,'y'); title(ax,'1R: x=l cos theta, y=l sin theta');
end
