function demo02_rotation_2d
% Slides 10-12: 2D rotation and active/passive viewpoint.
root=fileparts(fileparts(mfilename('fullpath'))); addpath(fullfile(root,'helpers'));
clc; theta=deg2rad(30); R=rot2(theta); v=[1;0]; vRot=R*v;
fprintf('R(30 deg)=\n'); disp(R); fprintf('R*v = [%g %g]^T\n',vRot);
fprintf('R(90 deg)*[1;0] = '); disp(rot2(pi/2)*[1;0]);
figure('Name','2D rotation'); ax=axes; hold(ax,'on'); axis(ax,'equal'); grid(ax,'on');
quiver(ax,0,0,v(1),v(2),0,'LineWidth',3); quiver(ax,0,0,vRot(1),vRot(2),0,'LineWidth',3);
plotFrame2D(ax,[R [0;0];0 0 1],'B',0.8); xlim(ax,[-.5 1.4]); ylim(ax,[-.5 1.4]);
title(ax,'2D rotation: columns of R are rotated basis vectors'); legend(ax,{'original vector','rotated vector'});
end
