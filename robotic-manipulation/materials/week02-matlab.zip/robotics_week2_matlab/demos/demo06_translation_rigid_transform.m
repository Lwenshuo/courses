function demo06_translation_rigid_transform
% Slides 22-23: translation and rigid transform.
root=fileparts(fileparts(mfilename('fullpath'))); addpath(fullfile(root,'helpers'));
clc;
pB=[1;0;0]; pOrigin=[2;1;0];
pA_translation=pB+pOrigin;
R=rotz3(pi/2); pA_rigid=R*pB+pOrigin;
fprintf('Pure translation: p_A = p_B + p_Borigin^A = '); disp(pA_translation.');
fprintf('Rigid transform: p_A = R_AB*p_B + p_Borigin^A = '); disp(pA_rigid.');
figure('Name','Translation and rigid transform'); ax=axes; hold(ax,'on'); grid(ax,'on'); axis(ax,'equal'); view(ax,2);
TA=eye(4); TB=homog(R,pOrigin); plotFrame3D(ax,TA,'A',0.5); plotFrame3D(ax,TB,'B',0.5);
plot3(ax,pA_rigid(1),pA_rigid(2),pA_rigid(3),'ko','MarkerFaceColor','k'); text(ax,pA_rigid(1),pA_rigid(2),0,'  P'); xlim(ax,[-1 4]); ylim(ax,[-1 4]);
end
