function demo13_planar_2R_homogeneous
% Slide 42: planar 2R using homogeneous transforms.
root=fileparts(fileparts(mfilename('fullpath'))); addpath(fullfile(root,'helpers'));
clc; l1=1; l2=0.6; q1=deg2rad(35); q2=deg2rad(50);
% Rotate first, then translate along local x by link length.
T01=tform2d(q1,[0;0])*tform2d(0,[l1;0]);
T12=tform2d(q2,[0;0])*tform2d(0,[l2;0]);
T02=T01*T12;
fprintf('T_2^0 =\n'); disp(T02);
fprintf('End position = [%.4f %.4f], phi=%.2f deg\n',T02(1,3),T02(2,3),rad2deg(atan2(T02(2,1),T02(1,1))));
figure('Name','2R homogeneous FK'); ax=axes; hold(ax,'on'); grid(ax,'on'); axis(ax,'equal');
plotFrame2D(ax,eye(3),'0',0.25); plotFrame2D(ax,T01,'1',0.25); plotFrame2D(ax,T02,'2',0.25);
plot(ax,[0 T01(1,3) T02(1,3)],[0 T01(2,3) T02(2,3)],'-o','LineWidth',4); title(ax,'T_2^0 = T_1^0 T_2^1');
end
