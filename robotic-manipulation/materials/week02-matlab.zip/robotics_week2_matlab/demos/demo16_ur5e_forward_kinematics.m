function demo16_ur5e_forward_kinematics
% Built-in robot example: Universal Robots UR5e.
% Requires Robotics System Toolbox.
root=fileparts(fileparts(mfilename('fullpath'))); addpath(fullfile(root,'helpers'));
clc;
if exist('loadrobot','file')~=2
    warning('Robotics System Toolbox/loadrobot not found. Skipping UR5e demo.'); return;
end
try
    robot=loadrobot("universalUR5e",DataFormat="row",Gravity=[0 0 -9.81]);
catch ME
    warning('Could not load universalUR5e: %s',ME.message); return;
end
q=homeConfiguration(robot);
q(:)=0;
vals=[0 -pi/3 pi/2 -pi/3 -pi/2 0]; q(1:min(6,numel(q)))=vals(1:min(6,numel(q)));
ee=robot.BodyNames{end};
T0E=getTransform(robot,q,ee);
fprintf('UR5e bodies: %d\n',numel(robot.BodyNames));
fprintf('End-effector body: %s\n',ee);
fprintf('T_0E from getTransform =\n'); disp(T0E);

figure('Name','Built-in UR5e forward kinematics');
show(robot,q,'Frames','on','PreservePlot',false); axis equal; view(135,20); title('UR5e - built-in rigidBodyTree');
end
