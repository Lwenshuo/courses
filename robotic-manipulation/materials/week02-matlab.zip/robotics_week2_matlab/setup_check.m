function setup_check
%SETUP_CHECK Check MATLAB/toolbox environment for this teaching package.
clc;
fprintf('=== Robotics Week 2 MATLAB setup check ===\n');
fprintf('MATLAB version: %s\n', version);
fprintf('Release: %s\n', version('-release'));

root = fileparts(mfilename('fullpath'));
addpath(root, fullfile(root,'demos'), fullfile(root,'helpers'));
fprintf('Project root added to path:\n  %s\n', root);

hasRobotics = ~isempty(ver('robotics')) || exist('rigidBodyTree','class') == 8 || exist('loadrobot','file') == 2;
fprintf('Robotics System Toolbox detected: %s\n', string(hasRobotics));

if hasRobotics
    try
        robot = loadrobot("universalUR5e", DataFormat="row"); %#ok<NASGU>
        fprintf('Built-in robot model universalUR5e: OK\n');
    catch ME
        fprintf('Built-in UR5e load test: FAILED\n');
        fprintf('  %s\n', ME.message);
        fprintf('Try Add-On Explorer -> Robotics System Toolbox / Robot Library Data.\n');
    end
else
    fprintf('Demos 16-17 will be skipped until Robotics System Toolbox is installed.\n');
end

fprintf('\nTip: run run_all_demos to execute the complete lecture sequence.\n');
end
