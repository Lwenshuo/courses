function plotFrame3D(ax,T,name,scale)
%PLOTFRAME3D Draw 3D coordinate frame from a 4x4 transform.
if nargin<4, scale=0.15; end
p=T(1:3,4); R=T(1:3,1:3);
q1=quiver3(ax,p(1),p(2),p(3),scale*R(1,1),scale*R(2,1),scale*R(3,1),0,'LineWidth',2); q1.Color=[0.85 0.1 0.1];
q2=quiver3(ax,p(1),p(2),p(3),scale*R(1,2),scale*R(2,2),scale*R(3,2),0,'LineWidth',2); q2.Color=[0.1 0.6 0.2];
q3=quiver3(ax,p(1),p(2),p(3),scale*R(1,3),scale*R(2,3),scale*R(3,3),0,'LineWidth',2); q3.Color=[0.1 0.25 0.9];
text(ax,p(1),p(2),p(3),['  ' name],'FontWeight','bold');
end
