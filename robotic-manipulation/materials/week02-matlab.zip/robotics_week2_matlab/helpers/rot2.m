function R = rot2(theta)
%ROT2 2-D rotation matrix, counterclockwise, radians.
R = [cos(theta) -sin(theta); sin(theta) cos(theta)];
end
