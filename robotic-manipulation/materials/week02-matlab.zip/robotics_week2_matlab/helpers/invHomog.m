function Ti = invHomog(T)
%INVHOMOG Analytic inverse of a rigid homogeneous transform.
R=T(1:3,1:3); p=T(1:3,4);
Ti=[R.' -R.'*p; 0 0 0 1];
end
