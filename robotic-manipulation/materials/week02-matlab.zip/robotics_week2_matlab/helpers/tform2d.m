function T = tform2d(theta,p)
%TFORM2D 3x3 planar homogeneous transform.
p=p(:);
T=[rot2(theta) p(1:2); 0 0 1];
end
