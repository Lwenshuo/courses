function R = rotz3(a)
%ROTZ3 3-D rotation about +z, radians.
ca=cos(a); sa=sin(a);
R=[ca -sa 0; sa ca 0; 0 0 1];
end
