function s = checkRotation(R)
%CHECKROTATION Return common SO(3) checks.
s.orthogonalityError = norm(R.'*R-eye(3),'fro');
s.determinant = det(R);
s.isRotation = s.orthogonalityError < 1e-10 && abs(s.determinant-1) < 1e-10;
end
