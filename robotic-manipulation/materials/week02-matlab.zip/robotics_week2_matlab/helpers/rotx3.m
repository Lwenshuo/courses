function R = rotx3(a)
%ROTX3 3-D rotation about +x, radians.
ca=cos(a); sa=sin(a);
R=[1 0 0; 0 ca -sa; 0 sa ca];
end
