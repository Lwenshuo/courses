function T = homog(R,p)
%HOMOG Build 4x4 homogeneous transform from 3x3 rotation and 3x1 translation.
p = p(:);
assert(all(size(R)==[3 3]), 'R must be 3x3.');
assert(numel(p)==3, 'p must have 3 elements.');
T=[R p; 0 0 0 1];
end
