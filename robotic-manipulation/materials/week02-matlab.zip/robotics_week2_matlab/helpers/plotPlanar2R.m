function [P1,P2] = plotPlanar2R(ax,l1,l2,q1,q2)
%PLOTPLANAR2R Plot a planar two-revolute-joint arm.
P0=[0;0];
P1=l1*[cos(q1); sin(q1)];
P2=P1+l2*[cos(q1+q2); sin(q1+q2)];
plot(ax,[P0(1) P1(1)],[P0(2) P1(2)],'-o','LineWidth',5,'MarkerSize',8); hold(ax,'on');
plot(ax,[P1(1) P2(1)],[P1(2) P2(2)],'-o','LineWidth',5,'MarkerSize',8);
plot(ax,P2(1),P2(2),'ko','MarkerFaceColor','k','MarkerSize',7);
axis(ax,'equal'); grid(ax,'on'); xlabel(ax,'x (m)'); ylabel(ax,'y (m)');
end
