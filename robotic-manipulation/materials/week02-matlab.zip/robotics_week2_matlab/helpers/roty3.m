function R = roty3(a)
%ROTY3 3-D rotation about +y, radians.
ca=cos(a); sa=sin(a);
R=[ca 0 sa; 0 1 0; -sa 0 ca];
end
