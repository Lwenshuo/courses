function plotFrame2D(ax,T,name,scale)
%PLOTFRAME2D Draw planar frame represented by 3x3 transform.
if nargin<4, scale=0.5; end
p=T(1:2,3); R=T(1:2,1:2);
quiver(ax,p(1),p(2),scale*R(1,1),scale*R(2,1),0,'LineWidth',2,'MaxHeadSize',0.6);
quiver(ax,p(1),p(2),scale*R(1,2),scale*R(2,2),0,'LineWidth',2,'MaxHeadSize',0.6);
text(ax,p(1),p(2),['  ' name],'FontWeight','bold');
end
